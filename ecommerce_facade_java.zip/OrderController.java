public class OrderController {
    public static void main(String[] args) {
        CheckoutFacade checkout = new CheckoutFacade();
        
        checkout.placeOrder(
            "MacBook Pro 16", 
            "KZ123456789", 
            2500.00, 
            "14 Abay Ave, Almaty", 
            "customer@example.com"
        );
    }
}
