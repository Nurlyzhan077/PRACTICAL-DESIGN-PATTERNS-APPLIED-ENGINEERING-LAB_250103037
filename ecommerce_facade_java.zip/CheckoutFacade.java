public class CheckoutFacade {
    private final InventoryService inventory;
    private final PaymentGateway payment;
    private final ShippingService shipping;
    private final NotificationService notification;

    public CheckoutFacade() {
        this.inventory = new InventoryService();
        this.payment = new PaymentGateway();
        this.shipping = new ShippingService();
        this.notification = new NotificationService();
    }

    public void placeOrder(String productId, String account, double amount, String address, String email) {
        System.out.println("=== Order processing started ===");
        
        if (inventory.checkStock(productId)) {
            if (payment.processPayment(account, amount)) {
                inventory.deductStock(productId);
                shipping.arrangeShipping(productId, address);
                notification.sendOrderConfirmation(email);
                System.out.println("=== Order placed successfully! ===");
            } else {
                System.out.println("Error: Payment failed.");
            }
        } else {
            System.out.println("Error: Out of stock.");
        }
    }
}
