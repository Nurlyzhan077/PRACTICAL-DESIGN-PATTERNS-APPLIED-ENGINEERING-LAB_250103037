public class InventoryService {
    public boolean checkStock(String productId) {
        System.out.println("[Inventory] Checking stock for: " + productId);
        return true;
    }

    public void deductStock(String productId) {
        System.out.println("[Inventory] Stock deducted for: " + productId);
    }
}
