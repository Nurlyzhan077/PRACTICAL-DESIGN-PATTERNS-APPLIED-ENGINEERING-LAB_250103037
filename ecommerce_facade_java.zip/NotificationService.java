public class NotificationService {
    public void sendOrderConfirmation(String email) {
        System.out.println("[Notification] Order confirmation email sent to: " + email);
    }
}
