public class ShippingService {
    public void arrangeShipping(String productId, String address) {
        System.out.println("[Shipping] Arranging delivery for " + productId + " to address: " + address);
    }
}
