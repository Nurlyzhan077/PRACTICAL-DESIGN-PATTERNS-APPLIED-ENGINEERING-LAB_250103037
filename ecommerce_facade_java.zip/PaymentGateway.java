public class PaymentGateway {
    public boolean processPayment(String account, double amount) {
        System.out.printf("[Payment] Processing payment of $%.2f from account %s...%n", amount, account);
        return true;
    }
}
